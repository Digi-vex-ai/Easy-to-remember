# Easy-to-remember
Source code for DigiVex, a Telegram mining game bot
